from flask_wtf import FlaskForm
from wtforms import StringField, TextField, PasswordField, SubmitField, BooleanField, IntegerField, SelectField, DateField, FloatField
from wtforms.validators import DataRequired, Length, Email, EqualTo, NumberRange, Regexp


class RegistrationForm(FlaskForm):
    username = StringField('Use Name', validators=[DataRequired(), Length(min=6, max=20)],
                            render_kw={"placeholder": "myusername"})
    firstname = StringField('First Name',validators=[DataRequired(), Length(min=3, max=15)],
                            render_kw={"placeholder": "Samuel as in Samuel Mbah Nde"})
    lastname = StringField('Last Name', validators=[DataRequired(), Length(min=3, max=15)],
                            render_kw={"placeholder": "Nde as in Samuel Mbah Nde"})
    phonenumber = StringField('Phone Number', validators=[DataRequired(), Length(min=12, max=12), Regexp(regex='\+1[2-9]{1}[0-9]{9}', message='Make Sure your number is formated like +19876543210')],
                            render_kw={"placeholder": "+19876543210"})
    dob = DateField('Date of Birth', validators=[DataRequired()], format='%m/%d/%Y',
                            render_kw={"placeholder": "mm/dd/yyyy"})
    email = StringField('Email', validators=[DataRequired(), Email()],
                        render_kw={"placeholder": "example@email.com"})
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8, max=16)],
                            render_kw={"placeholder": "password"})
    confirm_password = PasswordField('Confirm Password',
                                     validators=[DataRequired(), EqualTo('password')],
                                     render_kw={"placeholder": "repeat password"})
    sex = SelectField(u'Choose Your Sex', validators=[DataRequired()],
                     choices=[("male", "Male"), ('female', 'Female')])
    country = SelectField(u'Choose Your Country', validators=[DataRequired()],
                     choices=[("CMR", "Cameroon"), ('USA', 'United States')])
    submit = SubmitField('Sign Up')


class LoginForm(FlaskForm):
    username = StringField('User Name', validators=[DataRequired(), Length(min=6, max=20)],
                            render_kw={"placeholder": "YourUserName"})
    phonenumber = StringField('Phone Number', validators=[DataRequired(), Length(min=12, max=12), Regexp(regex='\+1[2-9]{1}[0-9]{9}', message='Make Sure your number is formated like +19876543210')],
                              render_kw={"placeholder": "+19876543210"})
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8, max=16)])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')

class MakeTransaction(FlaskForm):
    username = StringField('User Name', validators=[DataRequired(), Length(min=6, max=20)],
                            render_kw={"placeholder": "YourUserName"})
    firstname = StringField('First Name',validators=[DataRequired(), Length(min=3, max=15)],
                            render_kw={"placeholder": "Samuel as in Samuel Mbah Nde"})
    lastname = StringField('Last Name', validators=[DataRequired(), Length(min=3, max=15)],
                            render_kw={"placeholder": "Nde as in Samuel Mbah Nde"})
    email = StringField('Email', validators=[DataRequired(), Email()],
                        render_kw={"placeholder": "example@email.com"})
    phonenumber = StringField('Your Phone Number', validators=[DataRequired(), Length(min=12, max=12), Regexp(regex='\+1[2-9]{1}[0-9]{9}', message='Make Sure your number is formated like +19876543210')],
                            render_kw={"placeholder": "+19876543210"})
    recipientphone = StringField('Your Recipients Phone Number', validators=[DataRequired(), Length(min=12, max=12), Regexp(regex='\+1[2-9]{1}[0-9]{9}', message='Make Sure your number is formated like +19876543210')],
                            render_kw={"placeholder": "+19876543210"})
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8, max=16)],
                            render_kw={"placeholder": "password"})
    confirm_password = PasswordField('Confirm Password',
                                     validators=[DataRequired(), EqualTo('password')],
                                     render_kw={"placeholder": "repeat password"})
    amount = FloatField('Enter the amount you want to send:',validators=[DataRequired()],
                            render_kw={"placeholder": "3500.00"})
    country = SelectField(u'Choose Your Country', validators=[DataRequired()],
                     choices=[("CMR", "Cameroon"), ('USA', 'United States')])
    #AGGREEMENT = BooleanField('I AGREE to make this transaction. I acknowledge that this IS NOT A REVERSIBLE TRANSACTION.')
    submit = SubmitField('AUTHOURISE THIS PAYMENT')


class InternalTransactions(FlaskForm):
    username = StringField('User Name', validators=[DataRequired(), Length(min=6, max=20)],
                            render_kw={"placeholder": "yourINTERNALusername"})
    phonenumber = StringField('Your Recipients Phone Number', validators=[DataRequired(), Length(min=12, max=12), Regexp(regex='\+1[2-9]{1}[0-9]{9}', message='Make Sure your number is formated like +19876543210')],
                            render_kw={"placeholder": "+19876543210"})
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8, max=16)],
                            render_kw={"placeholder": "password"})
    desiredservice = SelectField(u'What Service do you want to use?', validators=[DataRequired()],
                     choices=[("RFAP", "Request From a Peer"), ('PAP', 'Pay a Peer'), ('MAC', 'Make a complaint')])
    submit = SubmitField('Confirm')

class RequestFromPeer(FlaskForm):
    username = StringField('User Name', validators=[DataRequired(), Length(min=6, max=20)],
                            render_kw={"placeholder": "yourINTERNALusername"})
    phonenumber = StringField('Your Recipients Phone Number', validators=[DataRequired(), Length(min=12, max=12), Regexp(regex='\+1[2-9]{1}[0-9]{9}', message='Make Sure your number is formated like +19876543210')],
                            render_kw={"placeholder": "+19876543210"})
    amountdesired = IntegerField('How much do you need', validators=[DataRequired(), NumberRange(min=10000, max=50000)],
                            render_kw={"placeholder": "16000"})
    submit = SubmitField('Submit Your Request')

class PayAPeer(FlaskForm):
    username = StringField('User Name', validators=[DataRequired(), Length(min=6, max=20)],
                            render_kw={"placeholder": "yourINTERNALusername"})
    phonenumber = StringField('Your Phone Number', validators=[DataRequired(), Length(min=12, max=12), Regexp(regex='\+1[2-9]{1}[0-9]{9}', message='Make Sure your number is formated like +19876543210')],
                            render_kw={"placeholder": "+19876543210"})
    recipientphone = StringField('Your Recipients Phone Number', validators=[DataRequired(), Length(min=12, max=12), Regexp(regex='\+1[2-9]{1}[0-9]{9}', message='Make Sure your number is formated like +19876543210')],
                            render_kw={"placeholder": "+19876543210"})
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8, max=16)],
                            render_kw={"placeholder": "password"})
    confirm_password = PasswordField('Confirm Password',
                                     validators=[DataRequired(), EqualTo('password')],
                                     render_kw={"placeholder": "repeat password"})
    amountpaid = IntegerField('How much are you paying?', validators=[DataRequired(), NumberRange(min=10000, max=50000)],
                            render_kw={"placeholder": "16000"})
    submit = SubmitField('Pay this Request')


class MakeACompliant(FlaskForm):
    username = StringField('User Name', validators=[DataRequired(), Length(min=6, max=20)],
                            render_kw={"placeholder": "yourINTERNALusername"})
    phonenumber = StringField('Your Phone Number', validators=[DataRequired(), Length(min=12, max=12), Regexp(regex='\+1[2-9]{1}[0-9]{9}', message='Make Sure your number is formated like +19876543210')],
                            render_kw={"placeholder": "+19876543210"})
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8, max=16)],
                            render_kw={"placeholder": "password"})
    complaint = TextField('How can we help?', validators=[DataRequired(), Length(min=20, max=100)],
                            render_kw={"placeholder": "Please tell us what the problem is."})
    submit = SubmitField('Submit')
