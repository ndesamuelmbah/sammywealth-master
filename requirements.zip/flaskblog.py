from datetime import datetime
from flask import Flask, render_template, url_for, flash, redirect
from flask_sqlalchemy import SQLAlchemy
from forms import RegistrationForm, LoginForm, MakeTransaction, PayAPeer, MakeACompliant, RequestFromPeer, InternalTransactions
import pyodbc
import re
import pandas as pd
import boto3
import s3fs
import urllib
import os
cnxn = os.environ['CNXN']


from flask import Flask
application = Flask(__name__)
application.config['SECRET_KEY'] = '5791628bb0b13ce0c676dfde280ba245'
application.config['SQLALCHEMY_DATABASE_URI'] = "mssql+pyodbc://masterserver:mypassword@sqlerver.cedpnaln5mjz.us-east-1.rds.amazonaws.com:1433/CustomerInfo?driver={SQL+Server}"
# application = Flask(__name__)
# application.config['SECRET_KEY'] = '5791628bb0b13ce0c676dfde280ba245'
#application.config['SQLALCHEMY_DATABASE_URI'] = "mssql+pyodbc:///?odbc_connect=DRIVER={SQL+Server};SERVER=sqlerver.cedpnaln5mjz.us-east-1.rds.amazonaws.com,1433;DATABASE=CustomerInfo;UID=masterserver;PWD=mypassword"
#"mssql+pyodbc:///?odbc_connect=DRIVERBSQL+Server%7D%3BSERVER%3Dsqlerver.cedpnaln5mjz.us-east-1.rds.amazonaws.com%2C1433%3BDATABASE%3DCustomerInfo%3BUID%3Dmasterserver%3BPWD%3Dmypassword"
#params = "DRIVER={SQL Server};SERVER=sqlerver.cedpnaln5mjz.us-east-1.rds.amazonaws.com,1433;DATABASE=CustomerInfo;UID=masterserver;PWD=mypassword"
#'sqlite:///site.db'
db = SQLAlchemy(application)
#mysql://username:password@server/db

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    firstname = db.Column(db.String(20), unique=False, nullable=False)
    lastname = db.Column(db.String(20), unique=False, nullable=False)
    phonenumber = db.Column(db.String(12), unique=True, nullable=False)
    dob = db.Column(db.DateTime, unique=False, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    image_file = db.Column(db.String(20), nullable=False, default='default.jpg')
    password = db.Column(db.String(60), nullable=False)
    sex = db.Column(db.String(10), unique=False, nullable=False)
    country = db.Column(db.String(42), unique=False, nullable=False)
    posts = db.relationship('Post', backref='author', lazy=True)

    def __repr__(self):
        return f"User('{self.username}', '{self.firstname}', '{self.lastname}', '{self.phonenumber}', '{self.dob}', '{self.email}', '{self.password}', '{self.image_file}', '{self.sex}', '{self.country}')"


class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    date_posted = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    content = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    def __repr__(self):
        return f"Post('{self.title}', '{self.date_posted}', '{self.content}')"


posts = [
    {
        'author': 'Samuel Nde',
        'title': 'How do I use your services?',
        'content': 'Good question. First register to join our network. Using the service is as simple as dailing *155#. We will send the instructions to your phone number.',
        'date_posted': 'March 17, 2019'
    },
    {
        'author': 'Samuel Nde',
        'title': "What if I don't have an email?",
        'content': 'Email is not a barrier! Just register with a valid phone number and we will send you more instructions.',
        'date_posted': 'March 17, 2019'
    }
]


@application.route("/")
@application.route("/home")
def home():
    return render_template('home.html', posts=posts)


@application.route("/about")
def about():
    return render_template('about.html', title='About')


@application.route("/internal", methods=['GET', 'POST'])
def internal():
    form = InternalTransactions()
    if form.validate_on_submit():
        try:
            numb = form.phonenumber.data
            pattern = re.compile('\+1[2-9]{1}[0-9]{9}')
            if not pattern.match(f'{numb}'):
                flash(f'Phone number format issue! \n Just one little problem! The required Phone Number format is {numb}. Please correct it and try again', category='danger')
            else:
                flash('Please give us a moment to verify your credentials.', 'success')
                conn = pyodbc.connect(cnxn)
                u = conn.execute(''' SELECT COUNT(*) count FROM InternalUsers
                                                             WHERE PhoneNumber = '{form.phonenumber.data}'
                                                             AND Password = '{form.password.data}'
                                                             AND UserName = '{form.username.data}' ''').fetchone()[0]
                conn.close()
                if u == 1 and form.desiredservice.data == 'RFAP':
                    flash(f'Hi {form.username.data}! Please fill this form to request for a peer transfer.', 'success')
                    return redirect(url_for('requestfrompeer'))
                elif u == 1 and form.desiredservice.data == 'PAP':
                    flash(f'Hi {form.username.data}! Please fill this form to pay your peer', 'success')
                    return redirect(url_for('requestfrompeer'))
                elif u == 1 and form.desiredservice.data == 'MAC':
                    flash(f'Hi {form.username.data}! Please tell us how we can help our business today.', 'success')
                    return redirect(url_for('makeacomplaint'))
                else:
                    flash(f'Sorry {form.username.data}! It looks like your password and user name does not match our records. Please provide the correct credentials', 'warning')
                    return redirect(url_for('login'))
        except:
            flash(f'We cannot log you in because we could not find matching details for {form.username.data}! Please try again.', 'danger')
            return redirect(url_for('internal'))
    return render_template('internal.html', title='For Internal Users Only', form=form)


@application.route("/requestfrompeer", methods=['GET', 'POST'])
def requestfrompeer():
    form = RequestFromPeer()
    if form.validate_on_submit():
        try:
            numb = form.phonenumber.data
            pattern = re.compile('\+1[2-9]{1}[0-9]{9}')
            if not pattern.match(f'{numb}'):
                flash(f'Phone number format issue! \n Just one little problem! The required Phone Number format is {numb}. Please correct it and try again', category='danger')
            else:
                flash('Please give us a moment to verify your credentials.', 'success')
                conn = pyodbc.connect(cnxn)
                u = conn.execute(''' SELECT COUNT(*) count FROM InternalUsers
                                                             WHERE PhoneNumber = '{form.phonenumber.data}'
                                                             AND Password = '{form.password.data}'
                                                             AND UserName = '{form.username.data}' ''').fetchone()[0]
                conn.close()
                if u == 1:
                    flash(f'Hi {form.username.data}. We have received your request and we are sending it to other users.', category='success')
                else:
                    flash(f'Sorry {form.username.data}! It looks like your password and user name does not match our records. Please provide the correct credentials', 'warning')
                    return redirect(url_for('login'))
        except:
            flash(f'We cannot log you in because we could not find matching details for {form.username.data}! Either you are not an internal user or your credentials are wrong.', 'danger')
            return redirect(url_for('internal'))
    return render_template('requestfrompeer.html', title='Request From A Peer', form=form)


@application.route("/makeacomplaint", methods=['GET', 'POST'])
def makeacomplaint():
    form = MakeACompliant()
    if form.validate_on_submit():
        try:
            numb = form.phonenumber.data
            pattern = re.compile('\+1[2-9]{1}[0-9]{9}')
            if not pattern.match(f'{numb}'):
                flash(f'Phone number format issue! \n Just one little problem! The required Phone Number format is {numb}. Please correct it and try again', category='danger')
                return redirect(url_for('makeacomplaint'))
            else:
                flash('Please give us a moment to verify your credentials.', 'success')
                conn = pyodbc.connect(cnxn)
                u = conn.execute(''' SELECT COUNT(*) count FROM InternalUsers
                                                             WHERE PhoneNumber = '{form.phonenumber.data}'
                                                             AND Password = '{form.password.data}'
                                                             AND UserName = '{form.username.data}' ''').fetchone()[0]
                conn.close()
                if u == 1:
                    flash(f'Hi {form.username.data}. We have received your request and we are sending it to other users.', category='success')
                    return redirect(url_for('home'))
                else:
                    flash(f'Sorry {form.username.data}! It looks like your password and user name does not match our records. Please provide the correct credentials', 'warning')
                    return redirect(url_for('login'))
        except:
            flash(f'We cannot log you in because we could not find matching details for {form.username.data}! Either you are not an internal user or your credentials are wrong.', 'danger')
            return redirect(url_for('internal'))
    return render_template('makeacomplaint.html', title='Request From A Peer', form=form)



@application.route("/payapeer", methods=['GET', 'POST'])
def payapeer():
    form = PayAPeer()
    if form.validate_on_submit():
        try:
            numb = form.phonenumber.data
            pattern = re.compile('\+1[2-9]{1}[0-9]{9}')
            if not pattern.match(f'{numb}'):
                flash(f'Phone number format issue! \n Just one little problem! The required Phone Number format is {numb}. Please correct it and try again', category='danger')
            else:
                flash('Please give us a moment to verify your credentials.', 'success')
                conn = pyodbc.connect(cnxn)
                u = conn.execute(''' SELECT COUNT(*) count FROM InternalUsers
                                                             WHERE PhoneNumber = '{form.phonenumber.data}'
                                                             AND Password = '{form.password.data}'
                                                             AND UserName = '{form.username.data}' ''').fetchone()[0]
                conn.close()
                if u == 1:
                    flash(f'Hi {form.username.data}. We have received your request and we are sending it to other users.', category='success')
                else:
                    flash(f'Sorry {form.username.data}! It looks like your password and user name does not match our records. Please provide the correct credentials', 'warning')
                    return redirect(url_for('login'))
        except:
            flash(f'We cannot log you in because we could not find matching details for {form.username.data}! Either you are not an internal user or your credentials are wrong.', 'danger')
            return redirect(url_for('internal'))
    return render_template('payapeer.html', title='Pay A Peer', form=form)

@application.route("/register", methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        flash(f'Please wait while we validate your record for {form.username.data}! We appreciate your business.', 'info')
        conn = pyodbc.connect(cnxn)
        UserName = form.username.data
        FirstName = form.firstname.data
        LastName = form.lastname.data
        Pasword = form.password.data
        PhoneNumber = form.phonenumber.data
        Email = form.email.data
        Dob = form.dob.data
        Sex = form.sex.data
        Country = form.country.data
        pattern = re.compile('\+1[2-9]{1}[0-9]{9}')
        if not pattern.match(f'{PhoneNumber}'):
            flash(f'Phone number format issue! \n One little problem {form.username.data}! The required Phone Number format is +12026408856. Please correct it and try again', category='danger')
        else:
            y = conn.execute('''SELECT COUNT(*) count FROM RegisteredUsers
                                                      WHERE PhoneNumber = '{}' '''.format(PhoneNumber)).fetchone()[0]
            if y == 1:
                flash(f'We could not create an account for {form.username.data} because we already have an account for {form.phonenumber.data}! \n Please login or use a different phone number.', 'danger')
            else:
                flash(f'We are creating an account for {form.username.data}. We will soon be done.', "message")
                conn.execute(''' INSERT INTO RegisteredUsers (FirstName, LastName, UserName, Email, Password, PhoneNumber, Dob, Sex, Country)
                                    VALUES ('{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}')'''.format(FirstName, LastName, UserName, Email, Pasword, PhoneNumber, Dob, Sex, Country))
                conn.commit()
                conn.close()
                flash(f'SUCCESS! \n We created an account for {form.username.data}! Please wait for confirmation', 'success')
                s3 = boto3.client(service_name = 's3', aws_access_key_id='AKIAJ6N26BHEBQBE66RQ', aws_secret_access_key='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')
                bucket = "myphonenumbers"
                file_name = "phonenumbers.csv"

                #s3 = boto3.client('s3')
                # 's3' is a key word. create connection to S3 using default config and all buckets within S3
                obj = s3.get_object(Bucket= bucket, Key= file_name)
                # get object and file (key) from bucket

                initial_df = pd.read_csv(obj['Body']) # 'Body' is a key word
                initial_df = pd.DataFrame(data = [PhoneNumber], columns = ['LastRegistered'])
                bytes_to_write = initial_df.to_csv(None).encode()
                fs = s3fs.S3FileSystem(key='AKIAJ6N26BHEBQBE66RQ', secret='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')
                with fs.open('s3://myphonenumbers/phonenumbers.csv', 'wb') as f:
                    f.write(bytes_to_write)

        return redirect(url_for('register'))
    return render_template('register.html', title='Register', form=form)


@application.route("/login", methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        try:
            numb = '+19876543210'
            pattern = re.compile('\+1[2-9]{1}[0-9]{9}')
            if not pattern.match(f'{numb}'):
                flash(f'Phone number format issue! \n Just one little problem! The required Phone Number format is {numb}. Please correct it and try again', category='danger')
            else:
                flash('Please give us a moment to verify your credentials.', 'success')
                conn = pyodbc.connect(cnxn)
                u = conn.execute(''' SELECT COUNT(*) count FROM RegisteredUsers
                                                             WHERE PhoneNumber = '{form.phonenumber.data}'
                                                             AND Password = '{form.password.data}'
                                                             AND UserName = '{form.username.data}' ''').fetchone()[0]
                conn.close()
                if u != 1:
                    flash(f'You are now logged in as {form.username.data}!', 'success')
                    return redirect(url_for('home'))
                else:
                    flash(f'Sorry {form.username.data}! It looks like your password and user name does not match our records. Please provide the correct credentials', 'warning')
                    return redirect(url_for('login'))
        except:
            flash(f'We cannot log you in because we could not find matching details for {form.username.data}! Please try again.', 'danger')
            return redirect(url_for('login'))
    return render_template('login.html', title='Login', form=form)


@application.route("/makeatransaction", methods=['GET', 'POST'])
def makeatransaction():
    form = MakeTransaction()
    if form.validate_on_submit():
        try:
            conn = pyodbc.connect(cnxn)
            UserName = form.username.data
            FirstName = form.firstname.data
            LastName = form.lastname.data
            Pasword = form.password.data
            Email = form.email.data
            PhoneNumber = form.phonenumber.data
            Recipient_PhoneNumber = form.recipientphone.data
            Country = form.country.data
            Amount = form.amount.data
            pattern = re.compile('\+1[2-9]{1}[0-9]{9}')
            if not (pattern.match(f'{PhoneNumber}') and pattern.match(f'{PhoneNumber}')):
                flash(f'Phone number format issue! \n One little problem {UserName}! The required Phone Number format is +12026408856. Please correct it and try again.', category='danger')
            elif Country != 'USA':
                flash(f'One little problem {UserName}! We only accept transactions to the US at this moment. We will soon be supporting transactions to {Country}.', category='danger')

            else:
                flash(f"You've been working hard. Spending your money should be easy!", 'info')
                y = conn.execute('''SELECT COUNT(*) FROM RegisteredUsers
                                                            WHERE UserName = '{}'
                                                            AND Password = '{}'
                                                            AND PhoneNumber ='{}' '''.format(UserName, Pasword, PhoneNumber)).fetchone()[0]
                if y != 1:
                    flash(f'We could not find the matching details for {form.username.data} in our system. \n  Please check that your phone number is {form.phonenumber.data}! \n Also ensure that your password is correct.', 'danger')
                    conn.close()
                else:
                    flash(f'We are logging into your account. Just give us one second {form.username.data}.', "message")
                    balance = conn.execute(''' SELECT Balance FROM RegisteredUsers
                                                                WHERE UserName = '{}'
                                                                AND Password = '{}'
                                                                AND PhoneNumber ='{}' '''.format(UserName, Pasword, PhoneNumber)).fetchone()[0]


                    if float(balance) >= float(Amount)*1.02:
                        flash(f'We are now performing the transaction.', "message")
                        new_balance =  float(balance) - float(Amount)*1.02
                        conn.execute(''' UPDATE RegisteredUsers
                                            SET Balance = {}
                                            WHERE UserName = '{}'
                                            AND Password = '{}'
                                            AND PhoneNumber ='{}' '''.format(new_balance, UserName, Pasword, PhoneNumber))
                        conn.commit()
                        conn.execute(''' INSERT INTO Transactions (UserName, FirstName, LastName, Password, FromPhoneNumber, ToPhoneNumber, Country, TransactionAmount, Email)
                                                VALUES ('{}', '{}', '{}', '{}', '{}', '{}', '{}', {}, '{}') '''.format(UserName, FirstName, LastName, Pasword, PhoneNumber, Recipient_PhoneNumber, Country, Amount, Email))
                        conn.close()
                        flash(f'SUCCESS! \n You have successfully sent {Amount}. to {Recipient_PhoneNumber}! Your new balance is {new_balance}.', 'success')

                        sns = boto3.client(service_name = 'sns', aws_access_key_id='AKIAJ6N26BHEBQBE66RQ', aws_secret_access_key='es9Pl+3hYVZWs+K0f8AHHDlTGv2wrZ8th80wz9Ik', region_name = 'us-east-1')
                        sns.publish(PhoneNumber=f"{Recipient_PhoneNumber}",
                                    Message=f"Dear customer, your account has been credited with {Amount}ftp. Thank you for trusting fasTEXpay. \n We appreciate your business!"
                                    )
                        sns.publish(PhoneNumber=f"{PhoneNumber}",
                                    Message=f"You just sent {Amount}ftp to {Recipient_PhoneNumber}. Thank you for trusting fasTEXpay. \n We appreciate your business!"
                                    )
        except:
            flash(f'Sorry {form.username.data}! Something went wrong with your request. Please try again.')
        return redirect(url_for('makeatransaction'))
    return render_template('makeatransaction.html', title='Make A Transaction', form=form)



if __name__ == '__main__':
    application.run(debug=True)
