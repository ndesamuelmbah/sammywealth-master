server = 'sqlerver.cedpnaln5mjz.us-east-1.rds.amazonaws.com:1433'
datbase = 'CustomerInfo'
usrname = 'masterserver'
passwd = 'mypassword'
cnxn = 'DRIVER={SQL Server};SERVER='+server+';DATABASE='+datbase+';UID='+usrname+';PWD='+ passwd
aws_access_key_id='AKIAJ6N26BHEBQBE66RQ'
aws_secret_access_key='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'
region_name = 'us-east-1'
bucket = "myphonenumbers"
file_name = "phonenumbers.csv"
